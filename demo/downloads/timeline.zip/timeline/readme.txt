1) Import timeline.sql
2) Go to class/config.php
3) Change server,username,password and database