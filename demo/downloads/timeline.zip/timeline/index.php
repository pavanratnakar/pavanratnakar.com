<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <meta name="keywords" content="Facebook, Timeline, jQuery, PHP, MYSQL, MYSQLI, Pavan Ratnakar, Pavan Ratnkar Applications, Pavan" />
        <meta name="description" content="Facebook timeline design using jQuery, PHP, mySQLi" />
        <meta name="author" content="Pavan Ratnakar" />
        <meta name="robots" content="index, follow" />
        <meta name="googlebot" content="index, follow" />
        <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
        <title>Pavan Ratnakar :: Facebook timeline design using jQuery, PHP, mySQLi</title>
        <link type="text/css" rel="stylesheet" media="all" href="css/timeline.css"/>    
    </head>
    <body>
        <div id="wrapper">
            <div id="main">
                <div id="mainContainer">
                    <h2>SIMPLE FACEBOOK TIMELINE DESIGN USING JQUERY, PHP &amp; MYSQLI</h2>
                    <div id="timeLine" >
                        <div class="timeLine_container left">
                            <div class="timeLine_bar left">
                                <div class="timeLine_plus"></div>
                            </div>
                        </div>
                        <div id="popup" class="left">
                            <div class="rightCorner" ></div>
                            <form action="" method="post" id="postForm">
                                <label for="postMessage">Whats in your heart?</label>
                                <textarea class="field" name="postMessage" id="postMessage" value="" size="23" type="text"></textarea>
                                <input type='submit' class="button" value="Post"/>
                            </form>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="clear"></div>
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
        <script type="text/javascript" src="js/jquery.masonry.min.js"></script>
        <script type="text/javascript" src="js/jquery.validate.min.js"></script>
        <script type="text/javascript" src="js/jquery.ajax.js"></script>
        <script type="text/javascript" src="js/timeline.js"></script>
    </body>
</html>