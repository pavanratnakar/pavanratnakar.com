<?php
class Config
{
    /* DB CONFIG */
    static $db_server='localhost';
    static $db_username='root';
    static $db_password='';
    static $db_database='demos';

    /* DB CONFIG */

    /* TIMELINE */
    static $demo_timeline="demo_timeline";
    /* TIMELINE */
}
?>