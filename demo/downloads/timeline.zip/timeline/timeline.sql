-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 04, 2012 at 03:41 PM
-- Server version: 5.1.37
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `demos`
--

-- --------------------------------------------------------

--
-- Table structure for table `demo_timeline`
--

CREATE TABLE IF NOT EXISTS `demo_timeline` (
  `post_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `not_delete` tinyint(1) NOT NULL,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `delete_flag` tinyint(1) NOT NULL DEFAULT '0',
  `post_message` varchar(256) DEFAULT NULL,
  `user_ip` varchar(200) NOT NULL,
  PRIMARY KEY (`post_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `demo_timeline`
--

INSERT INTO `demo_timeline` (`post_id`, `not_delete`, `post_date`, `delete_flag`, `post_message`, `user_ip`) VALUES
(10, 0, '2012-02-04 11:59:22', 1, 'I knw....... Sept 2012 mein start hogi shoting inshallah so tat mean 2013 mein relese hogi......Ye filmRukGayi thi dateTime nahi milaTha snjy duttKo', '2130706433'),
(11, 0, '2012-02-04 12:26:43', 0, 'Welcome to timeline. This is just a simple example of timeline design. Lot more updates to come.', '2130706433'),
(12, 0, '2012-02-04 15:39:39', 0, 'test', '2130706433');
